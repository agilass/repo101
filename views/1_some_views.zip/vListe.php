<?php
ob_start();
?>
<h1>Liste des �tudiants </h1>
<hr /><br /><br />
<table border= '1' bordercolor = 'red' cellpadding = '5' width = '80%' align = 'center'>

<tr> <th>Code</th>  <th>Nom</th>   <th>Pr�nom</th>  </tr>

<?php  while ($row = $resultat->fetch()) { ?>
  
<tr>
<td><a href='index.php?action=detail&Code=<?php echo $row[0] ?>'>
<?php echo $row[0] ;?>
</a></td>
 
<td><a href='index.php?action=detail&Code=<?php echo $row[0] ?>'>
<?php echo $row[1];?>
</a></td> 
<td><a href='index.php?action=detail&Code=<?php echo $row[0] ?>'>
<?php echo $row[2];?>
</a></td>
</tr>  
    
 <?php }?>
  
</table>

<?php
$page =ob_get_clean();
?>
